/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventmap;

import java.util.ArrayList;

/**
 *
 * @author Jonathan Cangelosi
 */
public class EventList {
    private static Event[] events=new Event[10];

    public static void insert(int i, Event e)
    {
        events[i]=e;
    }
    
    public static boolean hasEvent(int i)
    {
        return events[i]!=null;
    }
    
    public static Event getEvent(int i)
    {
        return events[i];
    }
}
