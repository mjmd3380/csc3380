/**
 * This file enables users to sign up or log in.
 * @author Michael Harrison
 * @see View
 */
package eventmap;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class UserInterface extends WindowAdapter implements ActionListener {
    String password;
    Model model;
    View view;
    
    public UserInterface(String title)
    {
    	model = new Model();
    	view = new View(title, this);
    	view.show();
	}

/* (non-Javadoc)
 * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
 */
    @Override
    public void windowClosing(WindowEvent e)
    {
    	// TODO Auto-generated method stub
    	view.close();
    }

    public void actionPerformed(ActionEvent e)
    {
		// TODO Auto-generated method stub

		String cmd = e.getActionCommand();

		 if (cmd.equals("Input Username"))
		 { // if username has been submitted
			String enter = view.getText();  // get the user name

	    	String accountLine = model.searchFile(enter);
	    	if(!accountLine.equals(""))
	    	{
				String firstName = accountLine.substring(0, accountLine.indexOf(' ')); // get first name
				String lastName = accountLine.substring(accountLine.indexOf(' ') + 1,
																accountLine.indexOf('\t')); // get last name
				password = accountLine.substring(accountLine.indexOf('\t') + 1); // get password. will be used later
				view.hide(); // make this screen invisible to start the password screen
				view.createNew(firstName,lastName, this); // start the password screen
	    	}
	    	else
	    	{
	    		view.setText(""); // the username is not found in the database
	    		view.setTitle("The User Name entered is incorrect. Please enter your user name");
	    		view.hide();
	    		view.show();
	    	}
	    }
		 
		if(cmd.equals("Create Account"))
		{
    		view.hide();
    		view.createSignUp("Enter Username and Student ID", this);
		}
		
		if(cmd.equals("New Account"))
		{
			password ="";
			password += view.getText();
			password += '\t';
			password += view.getText1();
			password += ' ';
			password += view.getText2();
			password += '\t';
			
			view.hide();
			view.createPassword("Enter Password", this);
		}
		
		if(cmd.equals("New Password"))
		{
			int lineNumber = model.compareID(password.substring(0, password.indexOf('\t')));
			String newPassword = view.getText1();
			if(newPassword.equals(view.getText2()))
			{
				password += newPassword;
				model.insertLine(password);
				view.hide();
				view.createIn(this);
//				new User(password.substring(0, password.indexOf('\t')));
			}
			else
			{
				view.setText("");
				view.setTitle("Passwords Don't Match");
				view.hide();
				view.show();
			}
		}
		
		if(cmd.equals("Input Password"))
		{ // password submitted 
			if(view.getText().equals(password))
			{  // password matches // do something here
				view.hide();
				view.createIn(this);
			}
			else
			{
				view.setText(""); // password does not match
				view.setTitle("Wrong Password");
				view.hide();
				view.show();
			}
		}

		if(cmd.equals("Logged In"))
		{
			view.hide();
			view.createStart("You have logged out", this);
		}
	}
}