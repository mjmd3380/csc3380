/**
 * This file is used to keep track of user account information.
 * @author Michael Harrison
 */
package eventmap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;

public class Model {
    private final static String filename = "loginfo.txt";
    File filePath;
    
    public Model() {
    	filePath = new File(filename);
    	try{
    	filePath.createNewFile();
    	}
		catch (IOException exception)
		{System.out.println("ERROR: data file has been closed!");}

    }
    
    public static String getFileName() {
    	return filename;
    }
    
    public File getFile() {
    	return filePath;
    }

    public String searchFile(String username) {
    	String accountLine = "";
    	try{
    		Scanner accountLookup = new Scanner(filePath);
	    	boolean gotAccount = false;
	    	while(accountLookup.hasNextLine() && !gotAccount)
	    	{
	    		accountLine = accountLookup.nextLine();
	    		gotAccount = accountLine.substring(accountLine.indexOf('\t') + 1, accountLine.indexOf('\t', accountLine.indexOf('\t')+1)).equals(username);
	    	}
	    	accountLookup.close();
	    	if(gotAccount)
	    		return accountLine;
	    	else return "";
    	}
    	catch(FileNotFoundException exception)
    	{
    		System.out.println("Error: no such file exists");
    	}
    	return accountLine;
    }
    
    public int compareID(String userID) {
    	int lineNumber = -1;
//    	int testID = 0;
    	String accountLine;
    	try{
    		Scanner accountLookup = new Scanner(filePath);
	    	boolean gotAccount = false;
	    	while(accountLookup.hasNextLine() && !gotAccount)
	    	{
	    		accountLine = accountLookup.nextLine();
	    		gotAccount = (accountLine.substring(0, accountLine.indexOf('\t')).equals(userID));
	    	}
	    	accountLookup.close();
	    	if(gotAccount)
	    		return lineNumber;
	    	else return -1;
    	}
    	catch(FileNotFoundException exception)
    	{
    		System.out.println("Error: no such file exists");
    	}
    	return lineNumber;
    }
    
    public void insertLine(String newLine)
    {
    	try
    	{
    		BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
    		writer.append(newLine);
    	}
    	catch(IOException e)
    	{
    		
    	}
    }


}