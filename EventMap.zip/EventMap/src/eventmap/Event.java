/**
 * This file contains details relevant to events that users create.
 * @author Jonathan Cangelosi
 */
package eventmap;
import java.util.*;

/**
 *
 * @author Jonathan Cangelosi
 */
public class Event 
{
    private String name;
    private String details;
    
    private boolean hasFood;
    private boolean hasMusic;
    private double entryFee;
    public Event(String n, String d, boolean f, boolean m, double e)
    {
        name=n;
        details=d;
        hasFood=f;
        hasMusic=m;
        entryFee=e;
    }
    public String getName()
    {
        return name;
    }
    public String getDetails()
    {
        return details;
    }
    public boolean hasFood()
    {
        return hasFood;
    }
    public boolean hasMusic()
    {
        return hasMusic;
    }
    public double getEntryFee()
    {
        return entryFee;
    }
}