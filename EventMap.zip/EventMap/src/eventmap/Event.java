/**
 * This file contains details relevant to events that users create.
 * @author Jonathan Cangelosi
 */
package eventmap;
import java.util.*;

/**
 *
 * @author Jonathan Cangelosi
 */
public class Event 
{
    private String name;
    private String details;
    private ArrayList<EventAspect> description;
    
    private double xCoord;
    private double yCoord;
    
    /**
     * Some additional descriptors for events.
     */
    private enum EventAspect
    {
        FOOD,
        MUSIC,
        ENTRY_FEE
    }
    
    public Event()
    {
        name="";
        details="";
        description=new ArrayList();
        
        xCoord=0;
        yCoord=0;
    }
    
    public Event(String n, String d, double x, double y)
    {
        name=n;
        details=d;
        description=new ArrayList();
        
        xCoord=x;
        yCoord=y;
    }
}
