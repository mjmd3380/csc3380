/**
 * This file contains implementation for a toolbar that accompanies the event 
 * map.
 * @author Dale Engelhorn
 */
package eventmap;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

class ClickedCreateEvent extends JFrame implements ActionListener {
 JLabel eventname;
 JButton submit;
 JTextField enterevent;
 JLabel eventdetails;
 JTextArea enterdetails;
 
    
    ClickedCreateEvent(){
        eventname = new JLabel("Event Name:");
        submit = new JButton("Submit");
        eventdetails = new JLabel("Event Details:");
        enterevent = new JTextField();
        enterdetails = new JTextArea();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Create Event");
        setSize(300,200);
        JPanel plane = new JPanel(new GridLayout(3,1));
            plane.add(eventname);
            plane.add(enterevent);
            plane.add(eventdetails);
            plane.add(enterdetails);
            add(plane,BorderLayout.SOUTH);
            plane.add(submit);
            submit.addActionListener(this);
            
    } 

    @Override
    public void actionPerformed(ActionEvent e) {
        String event = enterevent.getText();
        Random rand = new Random();
        int  n = rand.nextInt(50);
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put(event, n);

        try{
            FileWriter fw = new FileWriter("Events.txt");
            PrintWriter pw = new PrintWriter(fw);
            
            pw.println(map.get(event));
            pw.close();
            
        } 
        catch(IOException l){
            out.println("ERROR");
        }
    }
}

class ClickedFilterSettings extends JFrame {
    JCheckBox location;
    JCheckBox time;
    JCheckBox food;
    JCheckBox entry;
    JButton submit;
    
    ClickedFilterSettings(){
        location = new JCheckBox("Location");
        time = new JCheckBox("Time");
        food = new JCheckBox("Free Food");
        entry = new JCheckBox("Free Entry");
        submit = new JButton("Submit");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Create Event");
        setSize(300,200);
        JPanel plane = new JPanel(new GridLayout(3,1));
            plane.add(location);
            plane.add(time);
            plane.add(food);
            plane.add(entry);
            add(plane,BorderLayout.SOUTH);
            plane.add(submit);
}}

public class Toolbar extends JFrame {

    JToolBar tb;
    private JButton event = new JButton("Create Event");
    private JButton filter = new JButton("Filter Settings");
    private JButton toggle = new JButton("Display Toggle");
    private boolean setVisible;
    
 public Toolbar() {
     setSize(300,50);
     setTitle("Toolbar test");
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
     tb = new JToolBar();
     tb.setFloatable(false); 
     tb.add(event);
     tb.addSeparator();
     tb.add(filter);
     tb.addSeparator();
     tb.add(toggle);
     add(tb, BorderLayout.NORTH);
     
     event.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            ClickedCreateEvent nextevent = new ClickedCreateEvent();
            JLabel welcome = new JLabel("Fill out the information below and click submit.");
            nextevent.getContentPane().add(welcome);
            nextevent.setVisible(true);
            nextevent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         } 
     });
     
     filter.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            ClickedFilterSettings nextfilter = new ClickedFilterSettings();
            JLabel welcome = new JLabel("Check the boxes you want filtered below.");
            nextfilter.getContentPane().add(welcome);
            nextfilter.setVisible(true);
            nextfilter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         } 
     });
     
     toggle.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            
         } 
     });
     
 }
}
