/**
 * This file implements the User class, which has a username and moderator
 * status.
 * @author Michael Harrison
 */
package eventmap;

public class User {

	String userID;
	boolean isModerator;
	
	User(String userName)
	{
		userID = userName;
		isModerator = false;
	}
	
	void setModerator() {
		isModerator = true;
	}
	
	void notModerator() {
		isModerator = false;
	}
	
	String getUserID() {
		return userID;
	}
	
	boolean isModerator() {
		return isModerator;
	}
}
