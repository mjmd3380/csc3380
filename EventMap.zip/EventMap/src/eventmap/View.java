/**
 * This file provides some implementation for the login interface.
 * @author Michael Harrison
 * @see UserInterface
 */
package eventmap;

import java.awt.image.BufferedImage;
import javax.imageio.*;
import java.io.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.List;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.Toolkit;

import javax.swing.JPanel;

public class View {
//	Frame frame, frame1, frame2;
	Frame frame;

    JPanel buttonPanel, buttonPanel1, buttonPanel2;
    Button  blueButton;
    TextField tf, tf1, tf2;
    List list;
    Label loginLabel,loginLabel1, loggedInLabel;
    BufferedImage map;
	final static Rectangle r = new Rectangle(10,10,500,500);

    
    public View(String string, UserInterface ui) {
		createStart(string, ui);
    }

    // Make frame not visible
    public void hide() {
    	frame.setVisible(false);
    }

    // Make frame visible
    public void show() {
    	frame.setVisible(true);
    }

    // Close frame
    public void close() {
    	frame.dispose();
    }

    // Set title of frame
    public void setTitle(String title) {
    	frame.setTitle(title);
    }

    // Get text from TextField
    public String getText() {
    	return tf.getText();
    }
    
    public String getText1() {
    	return tf1.getText();
    }
    
    public String getText2() {
    	return tf2.getText();
    }

    // Set default text for TextField
    public void setText(String string) {
    	tf.setText(string);
    }

    
	public Frame prepareFrame(String title, UserInterface ui){
		Frame frame = new Frame(title);
		frame.setSize(950, 500);
		frame.setLayout(new BorderLayout());
		frame.setMaximizedBounds(r);
		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.addWindowListener(ui); // add a handler for events on this frame
		return frame;
	}
	
/*	public Frame prepareFrame(String title, BufferedImage image, UserInterface ui) {
		Frame frame = new Frame(title);
		frame.setSize(950, 500);;
		frame.setLayout(new BorderLayout());
		frame.setMaximizedBounds(r);
		ImageIcon imageIcon = new ImageIcon(image);
		JLabel jLabel = new JLabel();
		jLabel.setIcon(imageIcon);

		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.
		frame.addWindowListener(ui);
		return frame;
	}*/
	
	public Button prepareButton(String title, String actionCommand, UserInterface ui){
		Button redButton = new Button(title);
		redButton.setBackground(Color.RED);
		redButton.setActionCommand(actionCommand);
		redButton.addActionListener(ui);
		return redButton;
	}
	
	public JPanel prepareContainer(Frame frame){
		buttonPanel = new JPanel(new FlowLayout());
		// Dimension d = new Dimension(2000,2000); 
	    buttonPanel.setBounds(10,10,200,200);
	    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int x = Math.max(( screenSize.width / 2 - frame.getSize().width  / 2),0);
        int y = Math.max((screenSize.height / 2 - frame.getSize().height / 2),0);
        buttonPanel.setLocation(x,y);
        return buttonPanel;
	}

	// Create frame for entering username
	public void createStart(String title, UserInterface ui) {
		frame = prepareFrame(title, ui); // get a frame
		tf= new TextField("", 20); // get a Text Field
		loginLabel = new Label("User Name", Label.RIGHT);
	    loginLabel.setForeground(Color.BLUE);
	    buttonPanel = prepareContainer(frame); // get a panel
	    Button redButton = prepareButton("Submit", "Input Username", ui); // get a button
	    Button secondButton = prepareButton("Sign Up", "Create Account", ui);
		
		buttonPanel.add(loginLabel); // add label to panel
		buttonPanel.add(tf); // add text field to panel
		
		buttonPanel.add(redButton);//add button
		buttonPanel.add(secondButton);
		frame.add("Center", buttonPanel); // add the panel to the frame
		frame.setVisible(true);
	}

	// Get frame of View
	public Frame getFrame()
	{
		return frame;
	}


	// Create frame for entering password
    public void createNew(String firstName, String lastName, UserInterface ui){
// prepare a new screen for password
    	String title = "Welcome " + firstName + " " + lastName;
    	frame=prepareFrame(title, ui);
		tf= new TextField("", 20);
		loginLabel1 = new Label("Please Enter your Password", Label.RIGHT);
	    loginLabel1.setForeground(Color.BLUE);
	    buttonPanel1 = prepareContainer(frame);
		buttonPanel1.add(loginLabel1);
		buttonPanel1.add(tf);
	    blueButton = prepareButton("Submit","Input Password", ui);
    		buttonPanel1.add(blueButton);
		frame.add("Center", buttonPanel1);
		frame.setVisible(true);
    }

    
	// Create frame for entering password
    public void createSignUp(String title, UserInterface ui){
// prepare a new screen for password
    	title = "Create Account";
    	frame=prepareFrame(title, ui);
		tf1= new TextField("", 20);
		tf2= new TextField("", 20);
		tf= new TextField("", 10);
		loginLabel1 = new Label("Please Enter Name and ID", Label.RIGHT);
	    loginLabel1.setForeground(Color.BLUE);
	    buttonPanel1 = prepareContainer(frame);
		buttonPanel1.add(loginLabel1);
		buttonPanel1.add(tf1);
		buttonPanel1.add(tf2);
		buttonPanel1.add(tf);
	    blueButton = prepareButton("Submit","New Account", ui);
    		buttonPanel1.add(blueButton);
		frame.add("Center", buttonPanel1);
		frame.setVisible(true);
    }
    
	// Create frame for entering password
    public void createPassword(String title, UserInterface ui){
// prepare a new screen for password
    	title = "Enter Password";
    	frame=prepareFrame(title, ui);
		tf1= new TextField("", 20);
		tf2= new TextField("", 20);
		loginLabel1 = new Label("Please Enter and Verify Password", Label.RIGHT);
	    loginLabel1.setForeground(Color.BLUE);
	    buttonPanel1 = prepareContainer(frame);
		buttonPanel1.add(loginLabel1);
		buttonPanel1.add(tf1);
		buttonPanel1.add(tf2);
	    blueButton = prepareButton("Submit","New Password", ui);
    	buttonPanel1.add(blueButton);
		frame.add("Center", buttonPanel1);
		frame.setVisible(true);
    }

    // Create frame after logging in
    public void createIn(UserInterface ui) {
    	String title2 = "Loading the Image";
    	try {
    		map = ImageIO.read(new File("testimg.jpg"));
    	}
    	catch(IOException e)
    	{
    		
    	}
    	frame=prepareFrame(title2, ui);
    	loggedInLabel = new Label("Loading", Label.CENTER);
		ImageIcon imageIcon = new ImageIcon(map);
		JLabel jLabel = new JLabel();
		jLabel.setIcon(imageIcon);

    	loggedInLabel.setForeground(Color.BLUE);
    	buttonPanel1 = prepareContainer(frame);
    	buttonPanel1.add(loggedInLabel);
    	blueButton = prepareButton("Log Out", "Logged In", ui);
    	buttonPanel1.add(blueButton);
    	frame.add("North", buttonPanel1);
		frame.add("Center", jLabel);
    	frame.setVisible(true);    	
    }

	
}
