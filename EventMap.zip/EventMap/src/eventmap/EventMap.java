/**
 * This file contains the main method for this software project. We are making 
 * an application that uses social media-based elements to create a public 
 * event map.
 * @author Michael Harrison, Jonathan Cangelosi, Matt Jung, Dale Engelhorn
 */
package eventmap;

public class EventMap {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        new UserInterface("Login Screen");

        Toolbar t = new Toolbar();
        t.setVisible(true);
    }
}
