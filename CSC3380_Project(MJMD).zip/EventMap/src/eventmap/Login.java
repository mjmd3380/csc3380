/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventmap;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author Jonathan Cangelosi
 */
public class Login extends JFrame implements ActionListener{
    EventMap e;
    JButton SUBMIT;
    JPanel panel;
    JLabel user,pw;
    final JTextField  text1,text2;
    
    Login(EventMap em) {
        e=em;
        user = new JLabel();
        user.setText("Username:");
        text1 = new JTextField();

        pw = new JLabel();
        pw.setText("Password:");
        text2 = new JPasswordField();

        SUBMIT=new JButton("SUBMIT");

        panel=new JPanel(new GridLayout(6,2));
        panel.add(user);
        panel.add(text1);
        panel.add(pw);
        panel.add(text2);
        panel.add(SUBMIT);
        add(panel,BorderLayout.CENTER);
        SUBMIT.addActionListener(this);
        setTitle("Login Page");
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        String id =text1.getText();
        String password =text2.getText();
        
        if (id.equals("mjmd3380") && password.equals("compsci")) {
            this.setVisible(false);
            e.setSize(965, 525);
            e.setVisible(true);
        }
        
        else{
            System.out.println("enter the valid username and password");
            JOptionPane.showMessageDialog(this,"Incorrect login or password",
            "Error",JOptionPane.ERROR_MESSAGE);
    }
  }
}
